
public interface IOption {

	public void retrieve();
	public void insert();
	public void update();
	public void delete();
	
}
